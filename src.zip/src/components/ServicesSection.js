import React from "react";

const ServicesSection = () => {
  return (
    <section id="service" className="services">
      <div className="container">
        <h2>Services</h2>
        <p>
          Lorem ipsum dolor sit amet, consectetur adipiscing elit. Porttitor et,
          ultrices fermentum felis pretium.
        </p>
      </div>
    </section>
  );
};

export default ServicesSection;
